package in.codegram.cmapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CmApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
